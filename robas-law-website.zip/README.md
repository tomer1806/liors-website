# Robas Law — Website

Modern, responsive website for Lior Robas Law Office. Built with vanilla HTML/CSS/JS for maximum performance and simplicity.

## Project Structure

```
robas-law/
├── index.html          # Main homepage (single-page with all sections)
├── css/
│   └── style.css       # Complete stylesheet (RTL, responsive, animations)
├── js/
│   └── main.js         # Interactions (nav, scroll reveal, form, FAB)
├── assets/             # Images, logos, etc.
├── functions/
│   └── api/
│       └── contact.js  # Cloudflare Pages Function for contact form
├── _redirects          # Cloudflare redirects (www → non-www, HTTP → HTTPS)
├── _headers            # Security & caching headers
└── README.md
```

## Deploy to Cloudflare Pages

### Option 1: Direct Upload
1. Go to [Cloudflare Dashboard](https://dash.cloudflare.com) → Pages
2. Click "Create a project" → "Direct Upload"
3. Upload the entire project folder
4. Set custom domain: `robas-law.co.il`

### Option 2: Git Integration
1. Push this repo to GitHub/GitLab
2. In Cloudflare Pages → "Connect to Git"
3. Select your repo
4. Build settings:
   - **Build command:** (leave empty — no build needed)
   - **Output directory:** `/` (root)
5. Deploy

### DNS Setup
1. Add domain `robas-law.co.il` to Cloudflare
2. Update nameservers at your registrar to Cloudflare's
3. In Pages project → Custom Domains → Add `robas-law.co.il`

### Environment Variables (for contact form)
Set these in Cloudflare Pages → Settings → Environment Variables:
- `NOTIFICATION_EMAIL` — Email to receive form submissions
- `MAILGUN_API_KEY` — (optional) Mailgun API key for email delivery
- `MAILGUN_DOMAIN` — (optional) Mailgun sending domain

## Customization Checklist

- [ ] Replace phone numbers (`972XXXXXXXXX`) with real numbers
- [ ] Replace `lior@robas-law.co.il` with real email
- [ ] Add professional photos to `/assets/`
- [ ] Update office address in contact section
- [ ] Update practice area descriptions with real content
- [ ] Replace placeholder testimonials with real ones
- [ ] Update stats (years, clients, success rate) with real numbers
- [ ] Add Google Maps embed (optional)
- [ ] Add Google Analytics / Cloudflare Web Analytics
- [ ] Submit sitemap to Google Search Console

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Markup | Semantic HTML5 |
| Styling | Custom CSS (variables, grid, flexbox) |
| Fonts | Google Fonts (Frank Ruhl Libre, Noto Sans Hebrew) |
| Animations | CSS transitions + IntersectionObserver |
| Form Backend | Cloudflare Pages Functions |
| Hosting | Cloudflare Pages |
| CDN/SSL | Cloudflare (automatic) |

## Performance

- No build step, no framework overhead
- Total CSS ~15KB, JS ~5KB (before gzip)
- Google Fonts preconnect for fast loading
- Lighthouse target: 95+ across all categories
